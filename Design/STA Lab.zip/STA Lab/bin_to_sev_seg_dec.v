module bin_to_sev_seg_dec(
    input [7:0] bin,
    output [6:0] sev_seg2, sev_seg1, sev_seg0
);
    wire [3:0] bcd0, bcd1, bcd2;
    sev_seg_hex_dec u0 (bcd0, sev_seg0);
    sev_seg_hex_dec u1 (bcd1, sev_seg1);
    sev_seg_hex_dec u2 (bcd2, sev_seg2);
    bin_to_BCD_dec  u3 (bin, bcd0, bcd1, bcd2);
endmodule